package com.example.credito;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Details_Page extends AppCompatActivity {

    public static final String TAGG = "tagg";
    Spinner gender,marriage_status,dependents,education,self_emp,property_area,credit_history;
    EditText fname,lname,A_income,Co_income;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    Button upbtn;
    String userID;
    ProgressBar pgbr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details__page);

        gender = findViewById(R.id.genderv1);
        marriage_status = findViewById(R.id.Marriagetv1);
        dependents = findViewById(R.id.Depend_v1);
        education = findViewById(R.id.Education_v1);
        self_emp = findViewById(R.id.Selfemployedv1);
        property_area = findViewById(R.id.Property_v1);
        fname = findViewById(R.id.D1_FPersonName);
        lname = findViewById(R.id.D1_Ltxtv1);
        A_income = findViewById(R.id.Appliccantincomev1);
        Co_income = findViewById(R.id.Co_applicantincomenv1);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        upbtn = findViewById(R.id.uploadbtn);
        pgbr = findViewById(R.id.progressBar2);
        credit_history = findViewById(R.id.credit_history);

        upbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pgbr.setVisibility(View.VISIBLE);
/*
                String first_name = fname.getText().toString();
                String last_name = lname.getText().toString();
                String fgender = gender.getSelectedItem().toString();
                String fmarriagestatus = marriage_status.getSelectedItem().toString();
                String fdependents = dependents.getSelectedItem().toString();
                String feducation = education.getSelectedItem().toString();
                String fselfemp = self_emp.getSelectedItem().toString();
                String property = property_area.getSelectedItem().toString();
                String faincome = A_income.getText().toString();
                String fCoincome = Co_income.getText().toString();
                String fcredithistory = credit_history.getSelectedItem().toString();

 */
                opendetailfinal();



                /*
                userID = fAuth.getCurrentUser().getUid();
                DocumentReference documentReference = fStore.collection("Users").document(userID);

                Map<String,Object> user = new HashMap<>();
                user.put("User",first_name+" "+last_name);
                user.put("fname",first_name);
                user.put("lname",last_name);
                user.put("gender",fgender);
                user.put("marriage_status",fmarriagestatus);
                user.put("dependents",fdependents);
                user.put("Education",feducation);
                user.put("selfemp",fselfemp);
                user.put("Property_area",property);
                user.put("A_income",faincome);
                user.put("Co_income",fCoincome);
                user.put("Credit_History",fcredithistory);

                documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("tagg", "onSuccess: UserProfile is created for "+ userID);
                        opendetailfinal();
                    }
                });

                 */



            }
        });

    }

    public void opendetailfinal() {

        Intent intrdetail = new Intent(this, Displayresult.class);
        intrdetail.putExtra("fname",fname.getText().toString());
        intrdetail.putExtra("lname",lname.getText().toString());
        intrdetail.putExtra("gender",gender.getSelectedItem().toString());
        intrdetail.putExtra("marriage_status",marriage_status.getSelectedItem().toString());
        intrdetail.putExtra("dependents",dependents.getSelectedItem().toString());
        intrdetail.putExtra("Education",education.getSelectedItem().toString());
        intrdetail.putExtra("selfemp",self_emp.getSelectedItem().toString());
        intrdetail.putExtra("Property_area",property_area.getSelectedItem().toString());
        intrdetail.putExtra("A_income",A_income.getText().toString());
        intrdetail.putExtra("Co_income",Co_income.getText().toString());
        intrdetail.putExtra("Credit_History",credit_history.getSelectedItem().toString());
        startActivity(intrdetail);
    }
}