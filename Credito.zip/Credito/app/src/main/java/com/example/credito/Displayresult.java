package com.example.credito;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class Displayresult extends AppCompatActivity {
    TextView fullname,gender,marriage,dependents,education,selfemp,propertyarea,applicantincome,coapplicantincome,txtvw;
    FirebaseAuth fAuth;
    FirebaseFirestore fstore;
    String userid;
    EditText mloanamt;
    Button btnnv1;
    ProgressBar progressBargg;
    String userIDd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displayresult);

        fullname = findViewById(R.id.D1_Ltxtview);
        gender = findViewById(R.id.gender_txtview);
        marriage = findViewById(R.id.Marriagetxtview);
        dependents = findViewById(R.id.Depend_txtview);
        education = findViewById(R.id.Education_txtview);
        selfemp = findViewById(R.id.Selfemployedtxtview);
        propertyarea = findViewById(R.id.Property_txtview);
        applicantincome = findViewById(R.id.Appliccantincometxtview);
        coapplicantincome = findViewById(R.id.Co_applicantincomentxtview);
        btnnv1 = findViewById(R.id.uploadV1);
        txtvw = findViewById(R.id.tvtestextView17);
        mloanamt = findViewById(R.id.loanamt);
        progressBargg = findViewById(R.id.progressBar3);

        fAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        userid = fAuth.getCurrentUser().getUid();

        Intent intrdetail = getIntent();
        String kfname = intrdetail.getStringExtra("fname");
        String klname = intrdetail.getStringExtra("lname");
        String kgender = intrdetail.getStringExtra("gender");
        String kmarriage = intrdetail.getStringExtra("marriage_status");
        String kdependents = intrdetail.getStringExtra("dependents");
        String keducation = intrdetail.getStringExtra("Education");
        String kselfemp = intrdetail.getStringExtra("selfemp");
        String kpropertyarea = intrdetail.getStringExtra("Property_area");
        String kaincome = intrdetail.getStringExtra("A_income");
        String kcoincome = intrdetail.getStringExtra("Co_income");
        String kcreditstatus = intrdetail.getStringExtra("Credit_History");

        fullname.setText(kfname+" "+klname);
        gender.setText(kgender);
        marriage.setText(kmarriage);
        dependents.setText(kdependents);
        education.setText(keducation);
        selfemp.setText(kselfemp);
        propertyarea.setText(kpropertyarea);
        applicantincome.setText(kaincome);
        coapplicantincome.setText(kcoincome);





       /* DocumentReference documentReference = fstore.collection("Users").document(userid);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                fullname.setText(documentSnapshot.getString("User"));
                gender.setText(documentSnapshot.getString("gender"));
                marriage.setText(documentSnapshot.getString("marriage_status"));
                dependents.setText(documentSnapshot.getString("dependents"));
                education.setText(documentSnapshot.getString("education"));
                selfemp.setText(documentSnapshot.getString("selfemp"));
                propertyarea.setText(documentSnapshot.getString("property"));
                applicantincome.setText(documentSnapshot.getString("A_income"));
                coapplicantincome.setText(documentSnapshot.getString("Co_income"));



            }





        });

        */
        btnnv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBargg.setVisibility(View.VISIBLE);
                String fmloanamount = mloanamt.getText().toString();
                int finalValue=Integer.parseInt(fmloanamount);


                userIDd = fAuth.getCurrentUser().getUid();
                DocumentReference documentReference = fstore.collection("Users").document(userIDd);

                Map<String,Object> user = new HashMap<>();
                user.put("User",kfname+" "+klname);
                user.put("fname",kfname);
                user.put("lname",klname);
                user.put("gender",kgender);
                user.put("marriage_status",kmarriage);
                user.put("dependents",kdependents);
                user.put("Education",keducation);
                user.put("selfemp",kselfemp);
                user.put("Property_area",kpropertyarea);
                user.put("A_income",kaincome);
                user.put("Co_income",kcoincome);
                user.put("Credit_History",kcreditstatus);
                user.put("LoanAmount",finalValue);
                user.put("flag","1");


                documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("tagg", "onSuccess: Accessing Result "+ userIDd);
                        statres();
                    }
                });
            }
        });



    }

    private void statres() {
        Intent i = new Intent(this,resultpg1.class);
        startActivity(i);
    }
}