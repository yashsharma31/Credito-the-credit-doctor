package com.example.credito;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private Button Signup;
    FirebaseAuth fauth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fauth = FirebaseAuth.getInstance();
        if(fauth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),USerentered.class));
            finish();
        }




        button= findViewById(R.id.A_page_signin);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogin_page();
            }
        });
        Signup = findViewById(R.id.A_page_signup);
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignup();
            }
        });

    }

    private void openSignup() {
        Intent intsignup = new Intent(this, Registration_user.class);
        startActivity(intsignup);
    }


    private void openLogin_page() {
        Intent intent = new Intent(this, Login_page.class);
        startActivity(intent);
    }


}