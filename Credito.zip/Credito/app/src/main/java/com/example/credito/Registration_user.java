package com.example.credito;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Registration_user extends AppCompatActivity {
    public static final String TAG = "TAG";
    EditText mNAme,mEmail,mpassword,mPhonenumber,mcnfpswrd;
    Button mRegistrationbtn;
    FirebaseAuth fAuth;
    ProgressBar progressbarsignup;
    FirebaseFirestore fStore;
    String userID;
    Animation topAnimm;
    ImageView imggggl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_user);

        mNAme = findViewById(R.id.C_PersonName);
        mEmail = findViewById(R.id.C_EmailAddress);
        mpassword = findViewById(R.id.C_TextPassword);
        mcnfpswrd = findViewById(R.id.C_CnfPassword2);
        mPhonenumber = findViewById(R.id.C_Username);
        mRegistrationbtn = findViewById(R.id.C_regigisterbtn);
        fStore = FirebaseFirestore.getInstance();
        topAnimm = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        imggggl = findViewById(R.id.imageView3);
        imggggl.setAnimation(topAnimm);


        fAuth = FirebaseAuth.getInstance();
        progressbarsignup = findViewById(R.id.progressBar_SIGNIN);


        mRegistrationbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmail.getText().toString().trim();
                String password = mpassword.getText().toString().trim();
                String lumber = mPhonenumber.getText().toString();
                String name = mNAme.getText().toString();

                if (TextUtils.isEmpty(email)){
                    mEmail.setError("Email is Required.");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mpassword.setError("Password is Required.");
                    return;
                }
                if(password.length()<6){
                    mpassword.setError("Password must be >= 6 Characters");
                    return;
                }
                progressbarsignup.setVisibility(View.VISIBLE);

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Registration_user.this,"User Created.",Toast.LENGTH_SHORT).show();
                            userID = fAuth.getCurrentUser().getUid();
                            DocumentReference documentReference = fStore.collection("Users").document(userID);
                            Map<String,Object> user = new HashMap<>();
                            user.put("fname",name);
                            user.put("pnumber",lumber);
                            user.put("email",email);
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "onSuccess: UserProfile is created for "+ userID);
                                }
                            });

                            startActivity(new Intent(getApplicationContext(),USerentered.class));

                        }
                        else{
                            Toast.makeText(Registration_user.this,"Error! "+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            progressbarsignup.setVisibility(View.GONE);
                        }
                    }
                });

            }
        });
    }
}