package com.example.credito;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class resultpg1 extends AppCompatActivity {

    int count =10;
    Button btngetresult;
    FirebaseAuth jfAuth;
    FirebaseFirestore jfstore;
    String juserid;
    TextView jloanstatusad,jloanamt;
    TextView textvwcounter;
    Animation topAnimm, bottomAnimm;
    ImageView imagelgg;
    TextView txtinfo;
    View ly;
    ProgressBar pgbrgg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultpg1);

        textvwcounter = findViewById(R.id.counter);
        jfAuth = FirebaseAuth.getInstance();
        jfstore = FirebaseFirestore.getInstance();
        juserid = jfAuth.getCurrentUser().getUid();
        jloanamt = findViewById(R.id.laonamtad);
        jloanstatusad = findViewById(R.id.loanstatusad);
        btngetresult = findViewById(R.id.getresultbtn);
        imagelgg = findViewById(R.id.imageView7);
        String gg= "Approved";
        ly = findViewById(R.id.view);
        txtinfo = findViewById(R.id.info1hide);
        pgbrgg = findViewById(R.id.progressBar5);

        topAnimm = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnimm = AnimationUtils.loadAnimation(this,R.anim.botton_animations);

        Thread t =new Thread(){
            @Override
            public void run(){
                while(!isInterrupted()){
                    try{
                        Thread.sleep(1000);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                    count--;
                                    textvwcounter.setText((String.valueOf(count)));
                                    if(count == 0){
                                        getaldl();
                                        textvwcounter.setVisibility(View.INVISIBLE);
                                        jloanamt.setVisibility(View.VISIBLE);
                                        jloanstatusad.setVisibility(View.VISIBLE);
                                        pgbrgg.setVisibility(View.GONE);

                                        if(jloanstatusad.equals(gg)){
                                            ly.setBackgroundColor(R.color.bluebg);
                                            imagelgg.setAnimation(topAnimm);
                                            imagelgg.setVisibility(View.VISIBLE);
                                            txtinfo.setVisibility(View.VISIBLE);
                                        }
                                        else{
                                            ly.setBackgroundColor(R.color.redbg);
                                            imagelgg.setAnimation(topAnimm);
                                            imagelgg.setVisibility(View.VISIBLE);
                                            txtinfo.setVisibility(View.VISIBLE);

                                        }
                                    }
                            }
                        });
                    }
                    catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        };


        t.start();


    }

    public void getaldl() {
        DocumentReference documentReference = jfstore.collection("Users").document(juserid);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                jloanamt.setText(documentSnapshot.getString("Predicted_loan_amount"));
                jloanstatusad.setText(documentSnapshot.getString("loan_status"));

            }

        });
    }
}